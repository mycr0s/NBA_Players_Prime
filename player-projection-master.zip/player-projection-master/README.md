# player-projection
A NBA player comparison and projection app.

The website is at https://jamesyh.shinyapps.io/player_comparing_app/. 

It uses a simple least square euclidian distance algorithm with scaled data to find the 10 most similar players to the selected player. 

Sorry if the website is down, there is a limit for the free shiny application hosting.
